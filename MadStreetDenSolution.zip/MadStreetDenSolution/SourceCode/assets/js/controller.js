

var app = angular.module("FusionStyle",[]);

app.controller('MainController', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
    $scope.products = [];
    $scope.index = [];
    $scope.MyBookmarks = JSON.parse(localStorage.getItem('MyBookmarks')) || [];
    $scope.ProductVotes = JSON.parse(localStorage.getItem('ProductVotes')) || [];
    $http.get('https://hackerearth.0x10.info/api/fashion?type=json&query=list_products')
    .then(function (response) {
        $scope.products = response.data.products
        //alert(JSON.stringify(response.data));
        // alert($scope.products.length);
        $scope.initialAdjust();
    }, function (error) {
    });
    $scope.upVote = function (item) {
        item.up_votes += 1;
        item.total_votes += 1;
        for (var i = 0; i < $scope.ProductVotes.length; i++) {
            if (item.id == $scope.ProductVotes[i].id) {
                $scope.ProductVotes[i].total_votes += 1;
                $scope.ProductVotes[i].up_votes += 1;
                break;
            }
        }
        $scope.saveVotes();
    }
    $scope.downVote = function (item) {
        item.down_votes += 1;
        item.total_votes += 1;
        for (var i = 0; i < $scope.ProductVotes.length; i++) {
            if (item.id == $scope.ProductVotes[i].id) {
                $scope.ProductVotes[i].total_votes += 1;
                $scope.ProductVotes[i].down_votes += 1;
                break;
            }
        }
        $scope.saveVotes();
    }

    $scope.saveVotes = function () {
        localStorage.removeItem('ProductVotes');
        temp = JSON.stringify($scope.ProductVotes);
        localStorage.setItem('ProductVotes', temp);
    }
    $scope.viewDetails = function (Item) {
        $scope.selectedItem = Item;
        $scope.viewDetailCourse = true;
        document.getElementById('detail-overlay').style.display = "block";
    }
    $scope.hideDetails = function (Item) {
        $scope.selectedItem = {};
        document.getElementById('detail-overlay').style.display = "none";
    }
    $scope.initialAdjust = function () {
        for (var i = 0; i < $scope.products.length; i++) {
            var j = 0;
            for (j = 0; j < $scope.ProductVotes.length; j++) {
                if ($scope.products[i].id == $scope.ProductVotes[j].id) {
                    $scope.products[i].total_votes = $scope.ProductVotes[j].total_votes;
                    $scope.products[i].up_votes = $scope.ProductVotes[j].up_votes;
                    $scope.products[i].down_votes = $scope.ProductVotes[j].down_votes;
                    break;
                }
            } if (j == $scope.ProductVotes.length) {
                $scope.products[i].total_votes = 0;
                $scope.products[i].up_votes = 0;
                $scope.products[i].down_votes = 0;

                var obj = {
                    id: $scope.products[i].id,
                    total_votes: 0,
                    up_votes: 0,
                    down_votes: 0
                };
                $scope.ProductVotes.push(obj);
            }
            /* var hrs = $scope.products[i].hours;
            $scope.courses.paths[i].duration = parseFloat(hrs.substr(0, hrs.length - 1));
            var learners = $scope.courses.paths[i].learner;
            var comma = learners.indexOf(',');
            var learnerCount = learners.substr(0, comma) + learners.substr(comma + 1);
            $scope.courses.paths[i].learners_count = parseInt(learnerCount);*/
        }
    }
    $scope.showBookmark = function () {
        bookmarkShown = true;
       document.getElementById('bookmark').style.display = "block";
       // alert("Bookmark Shown");
    }
    $scope.hideBookmark = function () {
        bookmarkShown = false;
        document.getElementById('bookmark').style.display = "none";
       // alert("Bookmark hidden");
    }
    $scope.bookmark = function (selectedItem) {
        for (var i = 0; i < $scope.MyBookmarks.length; i++) {
            if ($scope.MyBookmarks[i].name === selectedItem.name) {
                break;
            }
        }
        if (i === $scope.MyBookmarks.length) {
            $scope.MyBookmarks.push(selectedItem);
        }
        localStorage.removeItem('MyBookmarks');
        temp = JSON.stringify($scope.MyBookmarks);
        localStorage.setItem('MyBookmarks', temp);
    }
} ]);


