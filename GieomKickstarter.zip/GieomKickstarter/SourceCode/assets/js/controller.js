

var app = angular.module("KickStart",[]);

app.controller('MainController', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
    $scope.projects = [];
    $scope.index = [];
    $scope.MyBookmarks = JSON.parse(localStorage.getItem('MyBookmarks')) || [];
    $scope.ProjectVotes = JSON.parse(localStorage.getItem('ProjectVotes')) || [];
    $scope.titles = [];
    $http.get('http://starlord.hackerearth.com/kickstarter')
    .then(function (response) {
        $scope.projects = response.data;
        //alert(JSON.stringify(response.data));
        // alert($scope.projects.length);
        $scope.initialAdjust();
    }, function (error) {
    });
    $scope.upVote = function (item) {
        item.up_votes += 1;
        item.total_votes += 1;
        for (var i = 0; i < $scope.ProjectVotes.length; i++) {
            if (item.title == $scope.ProjectVotes[i].title) {
                $scope.ProjectVotes[i].total_votes += 1;
                $scope.ProjectVotes[i].up_votes += 1;
                break;
            }
            
        }
        $scope.saveVotes();
    }
    $scope.downVote = function (item) {
        item.down_votes += 1;
        item.total_votes += 1;
        for (var i = 0; i < $scope.ProjectVotes.length; i++) {
            if (item.title == $scope.ProjectVotes[i].title) {
                $scope.ProjectVotes[i].total_votes += 1;
                $scope.ProjectVotes[i].down_votes += 1;
                break;
            }
        }
        $scope.saveVotes();
    }

    $scope.saveVotes = function () {
        localStorage.removeItem('ProjectVotes');
        temp = JSON.stringify($scope.ProjectVotes);
        localStorage.setItem('ProjectVotes', temp);
    }
    $scope.viewDetails = function (Item) {
        $scope.selectedItem = Item;
        $scope.viewDetailProject = true;
        document.getElementById('detail-overlay').style.display = "block";
        $scope.scrollPosition = document.getElementById('body').scrollTop;
        //alert($scope.scrollPosition);
        document.getElementById('body').scrollTop = 333;
    }
    $scope.hideDetails = function (Item) {
        $scope.selectedItem = {};
        document.getElementById('detail-overlay').style.display = "none";
        //alert($scope.scrollPosition);
        document.getElementById('body').scrollTop = $scope.scrollPosition;
    }
    $scope.initialAdjust = function () {
        for (var i = 0; i < $scope.projects.length; i++) {
            var d = $scope.projects[i]["end.time"];
            var arr = d.split("T");
            // alert(arr.length);
            var dtarr = arr[0].split("-");
            //alert(dtarr.length);
            var arr2 = arr[1].split("-");
            // alert(arr2[0])
            var tarr = arr2[0].split(":");
            var dt = new Date(dtarr[0], dtarr[1], dtarr[2], tarr[0], tarr[1], tarr[2], 0);
            //alert(dt.getTime() / 1000);
            $scope.projects[i].secondsSoFar = parseInt(dt.getTime() / 1000);
            $scope.projects[i].endDate = arr[0];
            $scope.projects[i].endTime = arr2[0];
            $scope.titles.push($scope.projects[i].title);
        }
        for (var i = 0; i < $scope.projects.length; i++) {
            var j = 0;
            for (j = 0; j < $scope.ProjectVotes.length; j++) {
                if ($scope.projects[i].title == $scope.ProjectVotes[j].title) {
                    $scope.projects[i].total_votes = $scope.ProjectVotes[j].total_votes;
                    $scope.projects[i].up_votes = $scope.ProjectVotes[j].up_votes;
                    $scope.projects[i].down_votes = $scope.ProjectVotes[j].down_votes;
                    break;
                }
            } if (j == $scope.ProjectVotes.length) {
                $scope.projects[i].total_votes = 0;
                $scope.projects[i].up_votes = 0;
                $scope.projects[i].down_votes = 0;

                var obj = {
                    title: $scope.projects[i].title,
                    total_votes: 0,
                    up_votes: 0,
                    down_votes: 0
                };
                $scope.ProjectVotes.push(obj);
            }

        }
    }
    $scope.showBookmark = function () {
        bookmarkShown = true;
        document.getElementById('bookmark').style.display = "block";
        // alert("Bookmark Shown");
    }
    $scope.hideBookmark = function () {
        bookmarkShown = false;
        document.getElementById('bookmark').style.display = "none";
        // alert("Bookmark hidden");
    }
    $scope.bookmark = function (selectedItem) {
        for (var i = 0; i < $scope.MyBookmarks.length; i++) {
            if ($scope.MyBookmarks[i].title === selectedItem.title) {
                break;
            }
        }
        if (i === $scope.MyBookmarks.length) {
            $scope.MyBookmarks.push(selectedItem);
        }
        localStorage.removeItem('MyBookmarks');
        temp = JSON.stringify($scope.MyBookmarks);
        localStorage.setItem('MyBookmarks', temp);
    }

} ]);


