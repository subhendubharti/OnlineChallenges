

var app = angular.module("FusionStyle",[]);

app.controller('MainController', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
    $scope.movies = [];
    $scope.index = [];
    $scope.MyBookmarks = JSON.parse(localStorage.getItem('MyBookmarks')) || [];
    $scope.MovieVotes = JSON.parse(localStorage.getItem('MovieVotes')) || [];
    $http.get('http://starlord.hackerearth.com/simility/movieslisting')
    .then(function (response) {
        $scope.movies = response.data;
        //alert(JSON.stringify(response.data));
        // alert($scope.movies.length);
        $scope.initialAdjust();
    }, function (error) {
    });
    $scope.upVote = function (item) {
        item.up_votes += 1;
        item.total_votes += 1;
        for (var i = 0; i < $scope.MovieVotes.length; i++) {
            if (item.movie_title == $scope.MovieVotes[i].movie_title) {
                $scope.MovieVotes[i].total_votes += 1;
                $scope.MovieVotes[i].up_votes += 1;
                break;
            }
        }
        $scope.saveVotes();
    }
    $scope.downVote = function (item) {
        item.down_votes += 1;
        item.total_votes += 1;
        for (var i = 0; i < $scope.MovieVotes.length; i++) {
            if (item.movie_title == $scope.MovieVotes[i].movie_title) {
                $scope.MovieVotes[i].total_votes += 1;
                $scope.MovieVotes[i].down_votes += 1;
                break;
            }
        }
        $scope.saveVotes();
    }

    $scope.saveVotes = function () {
        localStorage.removeItem('MovieVotes');
        temp = JSON.stringify($scope.MovieVotes);
        localStorage.setItem('MovieVotes', temp);
    }
    $scope.viewDetails = function (Item) {
        $scope.selectedItem = Item;
        $scope.viewDetailCourse = true;
        document.getElementById('detail-overlay').style.display = "block";
    }
    $scope.hideDetails = function (Item) {
        $scope.selectedItem = {};
        document.getElementById('detail-overlay').style.display = "none";
    }
    $scope.initialAdjust = function () {
        for (var i = 0; i < $scope.movies.length; i++) {
            var yr = parseInt($scope.movies[i].title_year);
            $scope.movies[i].year_oldToNew = yr;
            $scope.movies[i].year_newToOld = 2100 - yr;
        }
        for (var i = 0; i < $scope.movies.length; i++) {
            var j = 0;
            for (j = 0; j < $scope.MovieVotes.length; j++) {
                if ($scope.movies[i].movie_title == $scope.MovieVotes[j].movie_title) {
                    $scope.movies[i].total_votes = $scope.MovieVotes[j].total_votes;
                    $scope.movies[i].up_votes = $scope.MovieVotes[j].up_votes;
                    $scope.movies[i].down_votes = $scope.MovieVotes[j].down_votes;
                    break;
                }
            } if (j == $scope.MovieVotes.length) {
                $scope.movies[i].total_votes = 0;
                $scope.movies[i].up_votes = 0;
                $scope.movies[i].down_votes = 0;

                var obj = {
                    movie_title: $scope.movies[i].movie_title,
                    total_votes: 0,
                    up_votes: 0,
                    down_votes: 0
                };
                $scope.MovieVotes.push(obj);
            }
            /* var hrs = $scope.movies[i].hours;
            $scope.courses.paths[i].duration = parseFloat(hrs.substr(0, hrs.length - 1));
            var learners = $scope.courses.paths[i].learner;
            var comma = learners.indexOf(',');
            var learnerCount = learners.substr(0, comma) + learners.substr(comma + 1);
            $scope.courses.paths[i].learners_count = parseInt(learnerCount);*/
        }
    }
    $scope.showBookmark = function () {
        bookmarkShown = true;
        document.getElementById('bookmark').style.display = "block";
        // alert("Bookmark Shown");
    }
    $scope.hideBookmark = function () {
        bookmarkShown = false;
        document.getElementById('bookmark').style.display = "none";
        // alert("Bookmark hidden");
    }
    $scope.bookmark = function (selectedItem) {
        for (var i = 0; i < $scope.MyBookmarks.length; i++) {
            if ($scope.MyBookmarks[i].movie_title === selectedItem.movie_title) {
                break;
            }
        }
        if (i === $scope.MyBookmarks.length) {
            $scope.MyBookmarks.push(selectedItem);
        }
        localStorage.removeItem('MyBookmarks');
        temp = JSON.stringify($scope.MyBookmarks);
        localStorage.setItem('MyBookmarks', temp);
    }

    } ]);


