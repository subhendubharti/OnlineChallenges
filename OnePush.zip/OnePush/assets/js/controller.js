

var app = angular.module("GithubRepos",[]);

app.controller('MainController', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
    $scope.index = [];
    $scope.MyBookmarks = JSON.parse(localStorage.getItem('MyBookmarks')) || [];
    $scope.showBookmarks = false;
    $http.get('https://gist.githubusercontent.com/mayurah/5a4d45d12615d52afc4d1c126e04c796/raw/ccbba9bb09312ae66cf85b037bafc670356cf2c9/languages.json')
    .then(function (response) {
        $scope.Languages = response.data;
        //alert($scope.Languages.length);
        for (i = 0; i < $scope.Languages.length; i++) {
            $scope.index.push(i);
        }
    }, function (error) {
    });
   // $scope.repo = { "websites": [{ "id": "1", "title": "daniel g. siegel", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/42.png", "url_address": "http:\/\/www.dgsiegel.net\/", "tag": "personal" }, { "id": "2", "title": "Ross Penman", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/31.png", "url_address": "https:\/\/rosspenman.com\/", "tag": "Personal" }, { "id": "3", "title": "goker \/ resume", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/42.png", "url_address": "http:\/\/gokercebeci.com\/me", "tag": "Blog" }, { "id": "4", "title": "Gilles Quenot \/ SO", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/5.png", "url_address": "https:\/\/goo.gl\/fdr5Kq", "tag": "Social" }, { "id": "5", "title": "Nithin Rao Kumblekar", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/8.png", "url_address": "http:\/\/www.nithinkumblekar.com\/", "tag": "Caricature" }, { "id": "6", "title": "I am ben", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/5.png", "url_address": "http:\/\/www.iamben.co.uk\/", "tag": "Professional" }, { "id": "7", "title": "Mathias Karlsson", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/21.png", "url_address": "https:\/\/bounty.github.com\/researchers\/avlidienbrunn.html", "tag": "Security" }, { "id": "8", "title": "randomstream", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/13.png", "url_address": "http:\/\/kracekumar.com\/", "tag": "personal" }, { "id": "9", "title": "travisneilson", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/4.png", "url_address": "http:\/\/travisneilson.com\/", "tag": "personal" }, { "id": "10", "title": "adhamdannaway", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/10.png", "url_address": "http:\/\/www.adhamdannaway.com\/", "tag": "personal"}] };

     $http.get('https://hackerearth.0x10.info/api/one-push?type=json&query=list_websites')
    .then(function (response) {
        $scope.repo = response.data;
    }, function (error) {
    });
   // $scope.repo = { "websites": [{ "id": "1", "title": "daniel g. siegel", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/42.png", "url_address": "http:\/\/www.dgsiegel.net\/", "tag": "personal" }, { "id": "2", "title": "Ross Penman", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/31.png", "url_address": "https:\/\/rosspenman.com\/", "tag": "Personal" }, { "id": "3", "title": "goker \/ resume", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/42.png", "url_address": "http:\/\/gokercebeci.com\/me", "tag": "Blog" }, { "id": "4", "title": "Gilles Quenot \/ SO", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/5.png", "url_address": "https:\/\/goo.gl\/fdr5Kq", "tag": "Social" }, { "id": "5", "title": "Nithin Rao Kumblekar", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/8.png", "url_address": "http:\/\/www.nithinkumblekar.com\/", "tag": "Caricature" }, { "id": "6", "title": "I am ben", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/5.png", "url_address": "http:\/\/www.iamben.co.uk\/", "tag": "Professional" }, { "id": "7", "title": "Mathias Karlsson", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/21.png", "url_address": "https:\/\/bounty.github.com\/researchers\/avlidienbrunn.html", "tag": "Security" }, { "id": "8", "title": "randomstream", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/13.png", "url_address": "http:\/\/kracekumar.com\/", "tag": "personal" }, { "id": "9", "title": "travisneilson", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/4.png", "url_address": "http:\/\/travisneilson.com\/", "tag": "personal" }, { "id": "10", "title": "adhamdannaway", "favicon_image": "http:\/\/hackerearth.0x10.info\/api\/avatar\/10.png", "url_address": "http:\/\/www.adhamdannaway.com\/", "tag": "personal"}] };

    $scope.addSite = function (Item) {
        $scope.MyBookmarks.push(Item);
    }
    $scope.pushSite = function () {
        // alert("starting to push");
        $http.post('https://hackerearth.0x10.info/api/one-push?type=json&query=push&title=' + $scope.site.title + '&url=' + $scope.site.url + '&tag=' + $scope.site.tag)
    .then(function (response) {
        alert("successfully pushed");
    }, function (error) {
        alert("error");
    });
        $scope.site = {};
    }

    $scope.saveBookmarks = function () {
        localStorage.removeItem('MyBookmarks');
        temp = JSON.stringify($scope.MyBookmarks);
        // alert(cart.length);
        localStorage.setItem('MyBookmarks', temp);
    }
    $scope.clearBookmarks = function () {
        localStorage.removeItem('MyBookmarks');
        $scope.MyBookmarks = [];
    }
} ]);


