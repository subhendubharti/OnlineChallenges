var songList = [];
var App = (function () {
    var showData = function (data) {
        songList = data;
        var body = '<tbody>';
        for (var i = 0; i < data.length; i++) {
            var tr = '<tr>';
            var cover = '<td><img src="' + data[i].cover_image + '" alt="song"></td>';
            var song = '<td><h2>' + data[i].song + '</h2><h3>' + data[i].artists + '</h3></td>';
            var options = '<td style="vertical-align:middle"><h4><span onclick=App.play(' + i + ') >Play</span>&nbsp; &nbsp;<a href="' + data[i].url + '" download="' + data[i].song + '" ><span onclick=App.download(' + i + ')>Download</span></a>' +
            '&nbsp;&nbsp;<img src="images/star.png" onclick=App.star(' + i + ') alt="star" style="width:40px;height:40px;cursor:pointer"><h4></td';
            var row = tr + cover + song + options + "</tr>"
            body += row;
        }
        body += '</tbody>';
        $('#songTable').append(body);
        $('#songTable').dataTable({
            "pageLength": 3,
            "lengthMenu": [3, 5, 10],
            "info": false,
            "initComplete": function () {
                $('#songTable>thead').remove();
                $('#songTable_length').html("<label>Sureify-Coke Studio</label>");
                var tempvar = '<button class="btn btn-primary pull-right" onclick=Storage.display("Stars")>View Stars</button>&nbsp;&nbsp;' +
                '<button class="btn btn-primary pull-right" onclick=Storage.display("History")>View History</button>&nbsp;&nbsp;';
                $('#songTable_filter').append(tempvar);
                $('#songTable_length label').css("color", "white").css("font-size", 32); ;
                $('#songTable_filter input').css("height", 35);
            }
        });


    }
    var play = function (index) {
        $('#playerControls').show();
        var name = '<h1>' + songList[index].song + '</h1>'
        $('#songNameDisplay').html(name);

        var player = document.getElementById('player');
        var downloadLink = document.getElementById('downloadSong');
        downloadLink.href = songList[index].url;
        downloadLink.download = songList[index].song;
        if (!player.paused) {
            player.pause();
        }
        player.src = songList[index].url;
        player.play();
        Storage.save("Played song " + songList[index].song, "History");
        var b = document.getElementById("showHide");
        if (b == null) {
            $('#songTable_filter').append('<button id="showHide" class="btn pull-right" onclick="App.toggleControls()">Show/Hide Player Controls</button>');
        }
    }

    var star = function (index) {
        Storage.save(songList[index].song, 'Stars')
    }
    var playPause = function () {
        var player = document.getElementById('player');
        if (!player.paused) {
            player.pause();
        } else {
            player.play();
        }
    }
    var download = function (index) {
        //alert(index);
        Storage.save("Downloaded song " + songList[index].song, "History");
    }
    var trackDownload = function (elem) {
        Storage.save("Downloaded song " + elem.download, "History");
    }
    var toggleControls = function () {
        $('#playerControls').toggle();
    }
    return {
        showData: showData,
        play: play,
        playPause: playPause,
        star: star,
        download: download,
        trackDownload: trackDownload,
        toggleControls: toggleControls
    };
})();

var Storage = (function () {
    var save = function (item, itemStore) {
        var temp = JSON.parse(localStorage.getItem(itemStore)) || [];
        var d = new Date();
        temp.push(item + " at " + d.toString());
        if (localStorage.getItem(itemStore)) {
            localStorage.removeItem(itemStore);
        }
        localStorage.setItem(itemStore, JSON.stringify(temp));
    }
    var display = function (itemStore) {
        $('#overlay').css("visibility", "visible");
        $('#infoTable>tbody').remove();
        if (localStorage.getItem(itemStore)) {
            var itemsList = JSON.parse(localStorage.getItem(itemStore));
            var body = '<tbody>';
            for (var i = itemsList.length - 1; i >= 0; i--) {
                var tr = '<tr>';
                var td = '<td>' + itemsList[i] + '</td>';
                var row = tr + td + '</tr>';
                body += row;
            }
            if (itemStore == "History") {
                var hrow = '<tr><td><button class="btn btn-danger" onclick="Storage.clear()">Clear History</button></td></tr>';
                body += hrow;
            }
            body += '</tbody>';
            $('#infoTable').append(body);
        } else {
            $('#infoTable').append('<tbody><tr><td>No items to show</td></tr></tbody>');
        }

    }
    var clear = function () {
        if (localStorage.getItem("History")) {
            localStorage.removeItem("History")
        }
        $('#overlay').css("visibility", "hidden");
    }
    var hide=function(){
        $('#overlay').css("visibility", "hidden");
    }
    return {
        save: save,
        display: display,
        clear: clear,
        hide:hide
    }


})();
 $(document).ready(function () {
            $.getJSON("http://starlord.hackerearth.com/sureify/cokestudio", function (data) {
            App.showData(data);
        });
    });